
/* function to revert string */
void RevertString(char *str);

